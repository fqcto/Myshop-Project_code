<?php
include '../lock.php';
include '../../public/common/config.php';

$sql="select brand.*,class.name cname from brand,class where brand.class_id=class.id";
$rst=mysql_query($sql);
?>

<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>index</title>
	<link rel="stylesheet" type="text/css" href="../public/css/index.css">
</head>
<body>
	<div class="main">
		<div class='sxdiv'><a href="" class='shuaxin'>刷新</a></div>
		
		<table>
			<tr>
				<th>编号</th>
				<th>品牌名称</th>
				<th>分类名称</th>
				<th>修改</th>
				<th>删除</th>
			</tr>
			<?php
				while($row=mysql_fetch_assoc($rst)){
					echo "<tr>";
					echo "<td>{$row['id']}</td>";
					echo "<td>{$row['name']}</td>";
					echo "<td>{$row['cname']}</td>";
					echo "<td><a href='edit.php?id={$row['id']}'>修改</a></td>";
					echo "<td><a href='delete.php?id={$row['id']}' >删除</a></td>";
					echo "</tr>";
				}

			?>
		</table>
	</div>
</body>
</html>

