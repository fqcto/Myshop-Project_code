<?php
include 'lock.php';
?>
<!doctype html>
<html>
<head>
	<meta charset="UTF-8">
	<title>index</title>
</head>
<frameset rows="100,*" frameborder="0">
	<frame src="top.php" name="top">
	<frameset cols="190,*">
		<frame src="left.php" name="left">
		<frame src="right.php" name="right">
		
	</frameset>
</frameset>
</html>