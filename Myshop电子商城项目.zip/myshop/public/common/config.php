<?php 
error_reporting(0);
mysql_connect('localhost','root','123');
mysql_query('set names utf8');
mysql_select_db('myshop15');
?>