<?php 

echo '<script>location="home/index.php"</script>';

?>