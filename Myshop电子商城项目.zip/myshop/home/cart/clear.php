<?php
session_start();

$_SESSION['shops']=array();

echo "<script>location='index.php'</script>";
?>