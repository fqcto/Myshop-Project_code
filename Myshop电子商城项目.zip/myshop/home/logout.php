<?php 

session_start();

$arr=$_SESSION['shops'];

$_SESSION['home_username']=array();
$_SESSION['home_userid']=array();

$_SESSION['shops']=$arr;

echo '<script>location="login.php"</script>';
?>