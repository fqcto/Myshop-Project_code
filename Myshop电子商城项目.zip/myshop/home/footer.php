<div class="footer">
	<ul>
		<li><a href="">关于我们</a></li>
		<li><a href="">联系我们</a></li>
		<li><a href="">产品中心</a></li>
		<li><a href="">公司地图</a></li>
	</ul>
</div>