<?php 
$path=$_SERVER['PHP_SELF'];
$arr=explode('/',$path);
$root='/'.$arr[1];
?>
<div class="header">
	
		
	
	<div class="headerLeft">
		<a href="<?php echo $root?>/home/index.php">
		<span style="color:#fff">Myshop 商场</span></a>
	</div>
	<div class='headerRight'>
		<a href="<?php echo $root?>/home/index.php">首页</a>	
		<?php 
		if(!$_SESSION['home_userid']){
			echo "<a href='{$root}/home/login.php'>登录</a>";
		}else{
			echo "<a href='{$root}/home/person/index.php'>欢迎{$_SESSION['home_username']}登录</a><a href='{$root}/home/logout.php'>退出</a>";
		}
		?>
		<a href="<?php echo $root?>/home/register.php">注册</a>	
		<a href="<?php echo $root?>/home/person/index.php">个人中心</a>	
		<a href="<?php echo $root?>/home/cart/index.php">购物车</a>	
	</div>
</div>